/*
  +----------------------------------------------------------------------+
  | PHP Version 4                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2003 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 2.02 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available at through the world-wide-web at                           |
  | http://www.php.net/license/2_02.txt.                                 |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: IWAMA Kazuhiko <iwama@ymc.ne.jp>                             |
  +----------------------------------------------------------------------+

  $Id: header,v 1.10.8.1 2003/07/14 15:59:18 sniper Exp $ 
*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_idnkit.h"

ZEND_DECLARE_MODULE_GLOBALS(idnkit)

/* True global resources - no need for thread safety here */
static int le_idnkit;

/* {{{ idnkit_functions[]
 *
 * Every user visible function must have an entry in idnkit_functions[].
 */
function_entry idnkit_functions[] = {
	PHP_FE(idnkit_decodename,	NULL)
	PHP_FE(idnkit_encodename,	NULL)
	PHP_FE(idnkit_errno,		NULL)
	PHP_FE(idnkit_error,		NULL)
	{NULL, NULL, NULL}	/* Must be the last line in idnkit_functions[] */
};
/* }}} */

/* {{{ idnkit_module_entry
 */
zend_module_entry idnkit_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
	STANDARD_MODULE_HEADER,
#endif
	"idnkit",
	idnkit_functions,
	PHP_MINIT(idnkit),
	PHP_MSHUTDOWN(idnkit),
	PHP_RINIT(idnkit),
	NULL,
	PHP_MINFO(idnkit),
#if ZEND_MODULE_API_NO >= 20010901
	"0.1", /* Replace with version number for your extension */
#endif
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_IDNKIT
ZEND_GET_MODULE(idnkit)
#endif

/* {{{ prototypes */ 
/* }}} */

/* {{{ PHP_INI
 */
/* Remove comments and fill if you need to have entries in php.ini
PHP_INI_BEGIN()
    STD_PHP_INI_ENTRY("idnkit.global_value",      "42", PHP_INI_ALL, OnUpdateInt, global_value, zend_idnkit_globals, idnkit_globals)
    STD_PHP_INI_ENTRY("idnkit.global_string", "foobar", PHP_INI_ALL, OnUpdateString, global_string, zend_idnkit_globals, idnkit_globals)
PHP_INI_END()
*/
/* }}} */

/* {{{ php_idnkit_init_globals
 */
static void php_idnkit_init_globals(zend_idnkit_globals *idnkit_globals)
{
	idnkit_globals->idn_result = 0;
}
/* }}} */

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(idnkit)
{
	ZEND_INIT_MODULE_GLOBALS(idnkit, php_idnkit_init_globals, NULL);
/*
	REGISTER_INI_ENTRIES();
*/

	/* initialize idnkit*/
	idn_enable(1);
	idn_nameinit(1);

	/* get idnkit version */
	REGISTER_STRING_CONSTANT("IDNKIT_VERSION", (char*)idn_version_getstring(), CONST_CS | CONST_PERSISTENT);

	/* idnkit actions */
	REGISTER_LONG_CONSTANT("IDNKIT_DELIMMAP",		IDN_DELIMMAP,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_LOCALMAP",		IDN_LOCALMAP,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_MAP",			IDN_MAP,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_NORMALIZE",		IDN_NORMALIZE,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_PROHCHECK",		IDN_PROHCHECK,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_UNASCHECK",		IDN_UNASCHECK,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_BIDICHECK",		IDN_BIDICHECK,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_ASCCHECK",		IDN_ASCCHECK,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_IDNCONV",		IDN_IDNCONV,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_LENCHECK",		IDN_LENCHECK,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_RTCHECK",		IDN_RTCHECK,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_UNDOIFERR",		IDN_UNDOIFERR,		CONST_CS | CONST_PERSISTENT);

	REGISTER_LONG_CONSTANT("IDNKIT_ENCODE_QUERY",	IDN_ENCODE_QUERY,	CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_DECODE_QUERY",	IDN_DECODE_QUERY,	CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_ENCODE_APP",		IDN_ENCODE_APP,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_DECODE_APP",		IDN_DECODE_APP,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_ENCODE_STORED",	IDN_ENCODE_STORED,	CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_DECODE_STORED",	IDN_DECODE_STORED,	CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_NAMEPREP",		IDN_NAMEPREP,		CONST_CS | CONST_PERSISTENT);

	REGISTER_LONG_CONSTANT("IDNKIT_ENCODE_APP_ERR",	IDN_ENCODE_APP_ERR,	CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_DECODE_APP_ERR",	IDN_DECODE_APP_ERR,	CONST_CS | CONST_PERSISTENT);

	/* libidnkit result code */
	REGISTER_LONG_CONSTANT("IDNKIT_SUCCESS",			idn_success,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_NOTFOUND",			idn_notfound,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_INVALID_ENCODING",	idn_invalid_encoding,	CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_INVALID_SYNTAX",		idn_invalid_syntax,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_INVALID_NAME",		idn_invalid_name,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_INVALID_MESSAGE",	idn_invalid_message,	CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_INVALID_ACTION",		idn_invalid_action,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_INVALID_CODEPOINT",	idn_invalid_codepoint,	CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_INVALID_LENGTH",		idn_invalid_length,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_BUFFER_OVERFLOW",	idn_buffer_overflow,	CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_NOENTRY",			idn_noentry,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_NOMEMORY",			idn_nomemory,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_NOFILE",				idn_nofile,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_NOMAPPING",			idn_nomapping,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_CONTEXT_REQUIRED",	idn_context_required,	CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_PROHIBITED",			idn_prohibited,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("IDNKIT_FAILURE",			idn_failure,			CONST_CS | CONST_PERSISTENT);

	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(idnkit)
{
	/* uncomment this line if you have INI entries
	UNREGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(idnkit)
{
	IDNKIT_G(idn_result) = 0;

	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(idnkit)
{
	zval idnkit_ver;

	zend_get_constant("IDNKIT_VERSION", sizeof("IDNKIT_VERSION")-1, &idnkit_ver TSRMLS_CC);
	
	php_info_print_table_start();
	php_info_print_table_row(2, "idnkit support", "enabled");
	php_info_print_table_row(2, "idnkit library version", Z_STRVAL(idnkit_ver));
	php_info_print_table_end();

	/* Remove comments if you have entries in php.ini
	DISPLAY_INI_ENTRIES();
	*/

	zval_dtor(&idnkit_ver);
}
/* }}} */


/* {{{ proto string idnkit_encodename(string name [, int actions])
   Return a string to encode name. */
PHP_FUNCTION(idnkit_encodename)
{
	char string[256];
	char *name = NULL;
	int name_len;
	idn_result_t result;

	long actions = IDN_ENCODE_APP_ERR;

	if (ZEND_NUM_ARGS() == 1){
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &name, &name_len) == FAILURE) {
			return;
		}
	} else if (ZEND_NUM_ARGS() == 2){
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "sl", &name, &name_len, &actions) == FAILURE) {
			return;
		}
	} else {
		WRONG_PARAM_COUNT;
	}

	IDNKIT_G(idn_result) = idn_encodename(actions, name, string, sizeof(string) );

	if (IDNKIT_G(idn_result) == idn_success){
		RETURN_STRINGL(string, strlen(string), 1);
	} else {
		php_error(E_WARNING, idn_result_tostring(IDNKIT_G(idn_result)));
		RETURN_FALSE;
	}
}
/* }}} */

/* {{{ proto string idnkit_decodename(string name [, int actions])
   Return a string to decode name. */
PHP_FUNCTION(idnkit_decodename)
{
	char string[256];
	char *name = NULL;
	int name_len;

	long actions = IDN_DECODE_APP_ERR;

	if (ZEND_NUM_ARGS() == 1){
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &name, &name_len) == FAILURE) {
			return;
		}
	} else if (ZEND_NUM_ARGS() == 2){
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "sl", &name, &name_len, &actions) == FAILURE) {
			return;
		}
	} else {
		WRONG_PARAM_COUNT;
	}

	IDNKIT_G(idn_result) = idn_decodename(actions, name, string, sizeof(string) );

	if (IDNKIT_G(idn_result) == idn_success){
		RETURN_STRINGL(string, strlen(string), 1);
	} else {
		php_error(E_WARNING, idn_result_tostring(IDNKIT_G(idn_result)));
		RETURN_FALSE;
	}
}
/* }}} */

/* {{{ proto string idnkit_errno()
   Return a lastest error code. */
PHP_FUNCTION(idnkit_errno)
{
	RETURN_LONG(IDNKIT_G(idn_result));
}
/* }}} */

/* {{{ proto string idnkit_error()
   Return a lastest error string. */
PHP_FUNCTION(idnkit_error)
{
	RETURN_STRING( idn_result_tostring(IDNKIT_G(idn_result)), 1 );
}

/* }}} */
/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker nowrap
 * vim<600: noet sw=4 ts=4
 */
