/*
  +----------------------------------------------------------------------+
  | PHP Version 4                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2003 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 2.02 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available at through the world-wide-web at                           |
  | http://www.php.net/license/2_02.txt.                                 |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: IWAMA Kazuhiko <iwama@ymc.ne.jp>                             |
  +----------------------------------------------------------------------+

  $Id: header,v 1.10.8.1 2003/07/14 15:59:18 sniper Exp $ 
*/

#ifndef PHP_IDNKIT_H
#define PHP_IDNKIT_H

#ifdef HAVE_IDNKITLIB

extern zend_module_entry idnkit_module_entry;
#define phpext_idnkit_ptr &idnkit_module_entry

#ifdef PHP_WIN32
#define PHP_IDNKIT_API __declspec(dllexport)
#else
#define PHP_IDNKIT_API
#endif

#ifdef ZTS
#include "TSRM.h"
#endif

#include <idn/api.h>

#define IDN_ENCODE_APP_ERR \
  (idn_action_t)( IDN_DELIMMAP | IDN_LOCALMAP | IDN_MAP | IDN_NORMALIZE | IDN_PROHCHECK | IDN_BIDICHECK | IDN_ASCCHECK | IDN_IDNCONV | IDN_LENCHECK )

#define IDN_DECODE_APP_ERR \
  (idn_action_t)( IDN_DELIMMAP | IDN_MAP | IDN_NORMALIZE | IDN_PROHCHECK | IDN_BIDICHECK | IDN_IDNCONV | IDN_RTCHECK | IDN_ASCCHECK )


PHP_MINIT_FUNCTION(idnkit);
PHP_MSHUTDOWN_FUNCTION(idnkit);
PHP_RINIT_FUNCTION(idnkit);
PHP_RSHUTDOWN_FUNCTION(idnkit);
PHP_MINFO_FUNCTION(idnkit);

PHP_FUNCTION(idnkit_encodename);	/* idn_encodename warpper. */
PHP_FUNCTION(idnkit_decodename);	/* idn_decodename warpper. */

PHP_FUNCTION(idnkit_errno);		/* get lastest error code. */
PHP_FUNCTION(idnkit_error);		/* get lastest error string. */


ZEND_BEGIN_MODULE_GLOBALS(idnkit)
	long  idn_result;
ZEND_END_MODULE_GLOBALS(idnkit)

/* In every utility function you add that needs to use variables 
   in php_idnkit_globals, call TSRM_FETCH(); after declaring other 
   variables used by that function, or better yet, pass in TSRMLS_CC
   after the last function argument and declare your utility function
   with TSRMLS_DC after the last declared argument.  Always refer to
   the globals in your function as IDNKIT_G(variable).  You are 
   encouraged to rename these macros something shorter, see
   examples in any other php module directory.
*/

#ifdef ZTS
#define IDNKIT_G(v) TSRMG(idnkit_globals_id, zend_idnkit_globals *, v)
#else
#define IDNKIT_G(v) (idnkit_globals.v)
#endif

#else

#define phpext_idnkit_ptr NULL

#endif

#endif	/* PHP_IDNKIT_H */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: t
 * End:
 */
