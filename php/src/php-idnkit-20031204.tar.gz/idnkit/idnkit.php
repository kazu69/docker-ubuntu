<?
if(!extension_loaded('idnkit')) {
	dl('idnkit.' . PHP_SHLIB_SUFFIX);
}
$module = 'idnkit';
$functions = get_extension_funcs($module);
echo "Functions available in the test extension:<br>\n";
foreach($functions as $func) {
    echo $func."<br>\n";
}

echo "<br>\n";
$test = "xn--eckwd4c7c5976acvb2w6i.jp";
var_dump("Punycode: $test");
var_dump("UTF-8: ".idnkit_decodename($test));

echo "<br>\n";
$test = "日本語ドメイン.jp";
var_dump("UTF-8: $test");
var_dump("Punycode: ".idnkit_encodename($test));

echo "<br>\n";
$test = "_日本語ドメイン.jp";
var_dump("UTF-8: $test");
@idnkit_encodename($test);
var_dump("errno: ".idnkit_errno());
var_dump("error: ".idnkit_error());

echo "<br>\n";
?>
